package maonaroda;

import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class Terminal extends javax.swing.JFrame {

    Carro[] carro;
    Moto[] moto;
    
    public Terminal() {
        initComponents();
    }
    
    public void bird(Carro[] _carro, Moto[] _moto) {
        carro = _carro;
        moto = _moto;
    };

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jTextArea1.setBackground(new java.awt.Color(0, 0, 0));
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Consolas", 1, 12)); // NOI18N
        jTextArea1.setForeground(new java.awt.Color(255, 255, 255));
        jTextArea1.setRows(5);
        jTextArea1.setText("Cmd - version 1.0.9.1\ncopyright ₢ 2022 Senai. Todos direitos reservados.\n\n");
        jTextArea1.setBorder(null);
        jTextArea1.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jTextArea1.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jTextArea1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextArea1KeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(jTextArea1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 368, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 261, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jTextArea1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextArea1KeyPressed
        int tecla = evt.getKeyCode();
        int linha;
        String code;

        if (tecla == 10){
            String str[] = jTextArea1.getText().split("\n");
            linha = str.length - 1;
            code = str[linha];

            if (verificacao == false) {
                functionVerify(code);
            }
            if (verificacao == true) {
                function(code);
            }
        }
    }//GEN-LAST:event_jTextArea1KeyPressed

    public void function(String code) {
        switch (code) {
            case "date()":
            case "date();":
                jTextArea1.append("\nData e Hora: " + getDateTime() + ".");
                break;
            case "desligarSistema()":
            case "desligarSistema();":
                try { Thread.sleep (3000); } catch (InterruptedException ex) {}
                System.exit(0);
                break;
            case "exit()":
            case "exit();":                          
                Atendimento telaA = new Atendimento();
                telaA.bird(carro, moto);    
                
                TelaInicial telaI = new TelaInicial();
                telaI.bird(carro, moto); 
                
                dispose();
                break;
            case "limpaTela()":
            case "limpaTela();":
                jTextArea1.setText("cmd - version 1.0.9.1\ncopyright ₢ 2022 Senai. Todos direitos reservados.\n");
                break;
            case "status()":
            case "status();":
                jTextArea1.append("\n --- Status do sistema ---\n 48% - verificando.\n 83% - verificando..\n 100% - verificando...\n Verificação concluída com sucesso.\n - 0 erros apresentados.");
                break;
            default:
                if (code.length() >= 12){
                    if (paramFunction(code)){
                        alterarNome(code);
                    }
                }
                break;
        }
    }
    
    public boolean paramFunction(String _text){
        _text = _text.substring(1, 8);
        if (_text.equals("alterarNome(")){
        }
        return true;
    }
    
    public void alterarNome(String _text){
        String[] _textArray;
        int parametro = _text.length()-1;
        
        if (_text.substring(_text.length()-1, _text.length()).equals(";")){
            parametro--;
        }
        
        _text = _text.substring(12, parametro);
        _textArray = _text.split(",");
        for(int i = 0; i < _textArray.length; i++){
            _textArray[i] = _textArray[i].trim();
        }
        if (Integer.parseInt(_textArray[0]) < 7){
            carro[Integer.parseInt(_textArray[0])].setModelo(_textArray[1]);
        } else if (Integer.parseInt(_textArray[0]) < 16){
            int ID = Integer.parseInt(_textArray[0]) - 8;
            moto[ID].setModelo(_textArray[1]);
        } 
    }
    
        boolean verificacao = false;
    
    public void functionVerify(String code) {
         if (code.equals("/user (adm)./psw (****)") || code.equals("/user (adm)./psw (****);") || code.equals("/us")) {
             verificacao = true;
         } else if (code.equals("exit()") || code.equals("exit();")) {
             dispose();
         }
    }
    
    private String getDateTime() {
	DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	Date date = new Date();
	return dateFormat.format(date);
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Terminal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Terminal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Terminal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Terminal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Terminal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
}
