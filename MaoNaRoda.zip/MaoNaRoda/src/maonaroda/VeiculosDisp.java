package maonaroda;

public class VeiculosDisp extends javax.swing.JFrame {
    
    Carro[] carro;
    Moto[] moto;

    public VeiculosDisp() {
        initComponents();
    }
    
    public void bird(Carro[] _carro, Moto[] _moto) {
        carro = _carro;
        moto = _moto;
    };
    
    public void setNomeVeic(){
        carro1.setText(carro[0].modeloEValor());
        carro2.setText(carro[1].modeloEValor());
        carro3.setText(carro[2].modeloEValor());
        carro4.setText(carro[3].modeloEValor());
        carro5.setText(carro[4].modeloEValor());
        carro6.setText(carro[5].modeloEValor());
        carro7.setText(carro[6].modeloEValor());
        carro8.setText(carro[7].modeloEValor());
        
        moto1.setText(moto[0].modeloEValor());
        moto2.setText(moto[1].modeloEValor());
        moto3.setText(moto[2].modeloEValor());
        moto4.setText(moto[3].modeloEValor());
        moto5.setText(moto[4].modeloEValor());
        moto6.setText(moto[5].modeloEValor());
        moto7.setText(moto[6].modeloEValor());
        moto8.setText(moto[7].modeloEValor());

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        carro2 = new javax.swing.JLabel();
        carro3 = new javax.swing.JLabel();
        carro4 = new javax.swing.JLabel();
        carro1 = new javax.swing.JLabel();
        carro5 = new javax.swing.JLabel();
        carro6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        carro7 = new javax.swing.JLabel();
        carro8 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        moto2 = new javax.swing.JLabel();
        moto3 = new javax.swing.JLabel();
        moto4 = new javax.swing.JLabel();
        moto5 = new javax.swing.JLabel();
        moto6 = new javax.swing.JLabel();
        moto7 = new javax.swing.JLabel();
        moto1 = new javax.swing.JLabel();
        moto8 = new javax.swing.JLabel();

        jButton1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton1.setText("Voltar");
        jButton1.setFocusable(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(102, 255, 255));

        jButton2.setBackground(new java.awt.Color(0, 0, 0));
        jButton2.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Voltar");
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.setFocusable(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jButton2)
                .addContainerGap(67, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        carro2.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        carro2.setForeground(new java.awt.Color(0, 0, 0));
        carro2.setText("carro2");
        carro2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        carro2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                carro2MouseClicked(evt);
            }
        });

        carro3.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        carro3.setForeground(new java.awt.Color(0, 0, 0));
        carro3.setText("carro3");
        carro3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        carro3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                carro3MouseClicked(evt);
            }
        });

        carro4.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        carro4.setForeground(new java.awt.Color(0, 0, 0));
        carro4.setText("carro4");
        carro4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        carro4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                carro4MouseClicked(evt);
            }
        });

        carro1.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        carro1.setForeground(new java.awt.Color(0, 0, 0));
        carro1.setText("carro1");
        carro1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        carro1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                carro1MouseClicked(evt);
            }
        });

        carro5.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        carro5.setForeground(new java.awt.Color(0, 0, 0));
        carro5.setText("carro5");
        carro5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        carro5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                carro5MouseClicked(evt);
            }
        });

        carro6.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        carro6.setForeground(new java.awt.Color(0, 0, 0));
        carro6.setText("carro6");
        carro6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        carro6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                carro6MouseClicked(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Clique nas opções para saber mais");

        carro7.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        carro7.setForeground(new java.awt.Color(0, 0, 0));
        carro7.setText("carro7");
        carro7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        carro7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                carro7MouseClicked(evt);
            }
        });

        carro8.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        carro8.setForeground(new java.awt.Color(0, 0, 0));
        carro8.setText("carro8");
        carro8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        carro8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                carro8MouseClicked(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Consolas", 1, 31)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Veículos disponíveis");

        moto2.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        moto2.setForeground(new java.awt.Color(0, 0, 0));
        moto2.setText("moto2");
        moto2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        moto2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                moto2MouseClicked(evt);
            }
        });

        moto3.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        moto3.setForeground(new java.awt.Color(0, 0, 0));
        moto3.setText("moto3");
        moto3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        moto3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                moto3MouseClicked(evt);
            }
        });

        moto4.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        moto4.setForeground(new java.awt.Color(0, 0, 0));
        moto4.setText("moto4");
        moto4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        moto4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                moto4MouseClicked(evt);
            }
        });

        moto5.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        moto5.setForeground(new java.awt.Color(0, 0, 0));
        moto5.setText("moto5");
        moto5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        moto5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                moto5MouseClicked(evt);
            }
        });

        moto6.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        moto6.setForeground(new java.awt.Color(0, 0, 0));
        moto6.setText("moto6");
        moto6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        moto6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                moto6MouseClicked(evt);
            }
        });

        moto7.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        moto7.setForeground(new java.awt.Color(0, 0, 0));
        moto7.setText("moto7");
        moto7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        moto7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                moto7MouseClicked(evt);
            }
        });

        moto1.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        moto1.setForeground(new java.awt.Color(0, 0, 0));
        moto1.setText("moto1");
        moto1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        moto1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                moto1MouseClicked(evt);
            }
        });

        moto8.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        moto8.setForeground(new java.awt.Color(0, 0, 0));
        moto8.setText("moto8");
        moto8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        moto8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                moto8MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel5))
                        .addGap(123, 123, 123))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(carro4, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(moto4, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(carro5, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(moto5, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(carro1, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(moto1, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(carro2, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(moto2, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(carro3, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(moto3, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(carro8, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(moto8, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(carro6, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(carro7, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(moto6, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(moto7, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(15, 15, 15))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(58, 58, 58)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(carro1)
                    .addComponent(moto1))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(carro2)
                    .addComponent(moto2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(carro3)
                    .addComponent(moto3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(carro4)
                    .addComponent(moto4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(carro5)
                    .addComponent(moto5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(carro6)
                    .addComponent(moto6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(carro7)
                    .addComponent(moto7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(carro8)
                    .addComponent(moto8))
                .addContainerGap(68, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void carro1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_carro1MouseClicked
        DadosVeiculo dados = new DadosVeiculo();
        
        dados.bird(carro, moto);
        dados.recebeDadosCarro(0);
        dados.setVisible(true);
        dispose();
    }//GEN-LAST:event_carro1MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        TelaInicial tela = new TelaInicial();
        tela.bird(carro, moto);
        tela.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void carro2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_carro2MouseClicked
        DadosVeiculo dados = new DadosVeiculo();
        
        dados.bird(carro, moto);
        dados.recebeDadosCarro(1);
        dados.setVisible(true);
        dispose();
    }//GEN-LAST:event_carro2MouseClicked

    private void carro3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_carro3MouseClicked
        DadosVeiculo dados = new DadosVeiculo();
        
        dados.bird(carro, moto);
        dados.recebeDadosCarro(2);
        dados.setVisible(true);
        dispose();
    }//GEN-LAST:event_carro3MouseClicked

    private void carro4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_carro4MouseClicked
        DadosVeiculo dados = new DadosVeiculo();
        
        dados.bird(carro, moto);
        dados.recebeDadosCarro(3);
        dados.setVisible(true);
        dispose();
    }//GEN-LAST:event_carro4MouseClicked

    private void carro5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_carro5MouseClicked
        DadosVeiculo dados = new DadosVeiculo();
        
        dados.bird(carro, moto);
        dados.recebeDadosCarro(4);
        dados.setVisible(true);
        dispose();
    }//GEN-LAST:event_carro5MouseClicked

    private void carro6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_carro6MouseClicked
        DadosVeiculo dados = new DadosVeiculo();
        
        dados.bird(carro, moto);
        dados.recebeDadosCarro(5);
        dados.setVisible(true);
        dispose();
    }//GEN-LAST:event_carro6MouseClicked

    private void carro7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_carro7MouseClicked
        DadosVeiculo dados = new DadosVeiculo();
        
        dados.bird(carro, moto);
        dados.recebeDadosCarro(6);
        dados.setVisible(true);
        dispose();
    }//GEN-LAST:event_carro7MouseClicked

    private void carro8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_carro8MouseClicked
        DadosVeiculo dados = new DadosVeiculo();
        
        dados.bird(carro, moto);
        dados.recebeDadosCarro(7);
        dados.setVisible(true);
        dispose();
    }//GEN-LAST:event_carro8MouseClicked

    private void moto2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_moto2MouseClicked
        DadosVeiculo dados = new DadosVeiculo();
        
        dados.bird(carro, moto);
        dados.recebeDadosMoto(1);
        dados.setVisible(true);
        dispose();
    }//GEN-LAST:event_moto2MouseClicked

    private void moto3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_moto3MouseClicked
        DadosVeiculo dados = new DadosVeiculo();
        
        dados.bird(carro, moto);
        dados.recebeDadosMoto(2);
        dados.setVisible(true);
        dispose();
    }//GEN-LAST:event_moto3MouseClicked

    private void moto4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_moto4MouseClicked
        DadosVeiculo dados = new DadosVeiculo();
        
        dados.bird(carro, moto);
        dados.recebeDadosMoto(3);
        dados.setVisible(true);
        dispose();
    }//GEN-LAST:event_moto4MouseClicked

    private void moto5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_moto5MouseClicked
        DadosVeiculo dados = new DadosVeiculo();
        
        dados.bird(carro, moto);
        dados.recebeDadosMoto(4);
        dados.setVisible(true);
        dispose();
    }//GEN-LAST:event_moto5MouseClicked

    private void moto6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_moto6MouseClicked
        DadosVeiculo dados = new DadosVeiculo();
        
        dados.bird(carro, moto);
        dados.recebeDadosMoto(5);
        dados.setVisible(true);
        dispose();
    }//GEN-LAST:event_moto6MouseClicked

    private void moto7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_moto7MouseClicked
        DadosVeiculo dados = new DadosVeiculo();
        
        dados.bird(carro, moto);
        dados.recebeDadosMoto(6);
        dados.setVisible(true);
        dispose();
    }//GEN-LAST:event_moto7MouseClicked

    private void moto1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_moto1MouseClicked
        DadosVeiculo dados = new DadosVeiculo();
        
        dados.bird(carro, moto);
        dados.recebeDadosMoto(0);
        dados.setVisible(true);
        dispose();
    }//GEN-LAST:event_moto1MouseClicked

    private void moto8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_moto8MouseClicked
        DadosVeiculo dados = new DadosVeiculo();
        
        dados.bird(carro, moto);
        dados.recebeDadosMoto(7);
        dados.setVisible(true);
        dispose();
    }//GEN-LAST:event_moto8MouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VeiculosDisp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VeiculosDisp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VeiculosDisp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VeiculosDisp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VeiculosDisp().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel carro1;
    private javax.swing.JLabel carro2;
    private javax.swing.JLabel carro3;
    private javax.swing.JLabel carro4;
    private javax.swing.JLabel carro5;
    private javax.swing.JLabel carro6;
    private javax.swing.JLabel carro7;
    private javax.swing.JLabel carro8;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel moto1;
    private javax.swing.JLabel moto2;
    private javax.swing.JLabel moto3;
    private javax.swing.JLabel moto4;
    private javax.swing.JLabel moto5;
    private javax.swing.JLabel moto6;
    private javax.swing.JLabel moto7;
    private javax.swing.JLabel moto8;
    // End of variables declaration//GEN-END:variables

}
