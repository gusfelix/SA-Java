package maonaroda;

public class Carro extends Veiculo {
    
    private String cambio;
    
    public Carro(int id, int ano, String modelo, String marca, String cor, String img, double preco, String cambio) {
        super(id, ano, modelo, marca, cor, img, preco);
        this.cambio = cambio;
    }

    public String getCambio() {
        return cambio;
    }

    public void setCambio(String cambio) {
        this.cambio = cambio;
    }
}