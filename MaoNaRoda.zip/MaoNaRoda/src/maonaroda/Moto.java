package maonaroda;

public class Moto extends Veiculo{
    
    private int cilindros;
    
    public Moto(int id, int ano, int cilindros, String modelo, String marca, String cor, String img, double preco) {
        super(id, ano, modelo, marca, cor, img, preco);
        this.cilindros = cilindros;
    }

    public int getCilindros() {
        return cilindros;
    }

    public void setCilindros(int cilindros) {
        this.cilindros = cilindros;
    }
}